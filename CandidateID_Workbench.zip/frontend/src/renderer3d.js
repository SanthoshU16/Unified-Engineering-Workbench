// Zero-dependency WebGL 3D Engine for CAD (STL) and ANSYS Point Clouds
// Features: OrbitControls, Shaded Facets, Wireframe, Point Cloud Colormap, Raycasting Inspection

export class Renderer3D {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        if (!this.canvas) throw new Error(`Canvas #${canvasId} not found`);
        this.gl = this.canvas.getContext('webgl', { antialias: true, alpha: false });
        if (!this.gl) throw new Error('WebGL not supported');

        this.camera = {
            rotX: 25 * Math.PI / 180,
            rotY: -45 * Math.PI / 180,
            distance: 0.25,
            target: [0, 0, 0],
            fov: 45 * Math.PI / 180
        };

        this.mode = 'stl'; // 'stl' or 'points'
        this.stlData = null;
        this.pointsData = null;
        this.wireframe = false;
        this.hoveredNode = null;
        this.tooltipEl = null;

        this.initShaders();
        this.setupControls();
        this.resize();
    }

    setTooltipElement(el) {
        this.tooltipEl = el;
    }

    initShaders() {
        const gl = this.gl;

        // --- STL Shader (Position + Normal) ---
        const vsSTL = `
            attribute vec3 aPosition;
            attribute vec3 aNormal;
            uniform mat4 uMVP;
            uniform mat4 uModel;
            varying vec3 vNormal;
            varying vec3 vWorldPos;
            void main() {
                vNormal = aNormal;
                vWorldPos = (uModel * vec4(aPosition, 1.0)).xyz;
                gl_Position = uMVP * vec4(aPosition, 1.0);
            }
        `;
        const fsSTL = `
            precision mediump float;
            varying vec3 vNormal;
            varying vec3 vWorldPos;
            uniform vec3 uColor;
            uniform vec3 uLightDir;
            void main() {
                vec3 n = normalize(vNormal);
                float diff = max(dot(n, uLightDir), 0.0);
                float ambient = 0.35;
                vec3 lit = uColor * (ambient + diff * 0.75);
                gl_FragColor = vec4(lit, 1.0);
            }
        `;
        this.stlProgram = this.createProgram(vsSTL, fsSTL);

        // --- Point Cloud Shader (Position + Color) ---
        const vsPoints = `
            attribute vec3 aPosition;
            attribute vec3 aColor;
            uniform mat4 uMVP;
            uniform float uPointSize;
            varying vec3 vColor;
            void main() {
                vColor = aColor;
                gl_Position = uMVP * vec4(aPosition, 1.0);
                gl_PointSize = uPointSize;
            }
        `;
        const fsPoints = `
            precision mediump float;
            varying vec3 vColor;
            void main() {
                // Circle point shape
                vec2 coord = gl_PointCoord - vec2(0.5);
                if (length(coord) > 0.5) discard;
                gl_FragColor = vec4(vColor, 1.0);
            }
        `;
        this.pointsProgram = this.createProgram(vsPoints, fsPoints);

        gl.enable(gl.DEPTH_TEST);
        gl.clearColor(0.075, 0.082, 0.071, 1.0);
    }

    createProgram(vsSrc, fsSrc) {
        const gl = this.gl;
        const vs = gl.createShader(gl.VERTEX_SHADER);
        gl.shaderSource(vs, vsSrc);
        gl.compileShader(vs);

        const fs = gl.createShader(gl.FRAGMENT_SHADER);
        gl.shaderSource(fs, fsSrc);
        gl.compileShader(fs);

        const prog = gl.createProgram();
        gl.attachShader(prog, vs);
        gl.attachShader(prog, fs);
        gl.linkProgram(prog);
        return prog;
    }

    setSTLModel(model) {
        this.mode = 'stl';
        this.stlModel = model;
        const gl = this.gl;

        const positions = [];
        const normals = [];

        for (const tri of model.triangles) {
            // tri: [nx, ny, nz, v1x, v1y, v1z, v2x, v2y, v2z, v3x, v3y, v3z]
            const nx = tri[0], ny = tri[1], nz = tri[2];
            for (let v = 0; v < 3; ++v) {
                positions.push(tri[3 + v * 3], tri[4 + v * 3], tri[5 + v * 3]);
                normals.push(nx, ny, nz);
            }
        }

        this.stlVertexCount = positions.length / 3;

        this.stlPosBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, this.stlPosBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);

        this.stlNormBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, this.stlNormBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(normals), gl.STATIC_DRAW);

        this.fitToView(model.bbox_min, model.bbox_max);
        this.render();
    }

    setANSYSDataSet(dataset) {
        this.mode = 'points';
        this.ansysDataSet = dataset;
        const gl = this.gl;

        const positions = [];
        const colors = [];
        const minT = dataset.min_temperature;
        const maxT = dataset.max_temperature;
        const rangeT = (maxT > minT) ? (maxT - minT) : 1.0;

        for (const n of dataset.nodes) {
            // n: [node_id, x, y, z, temp]
            positions.push(n[1], n[2], n[3]);
            const normT = Math.max(0.0, Math.min(1.0, (n[4] - minT) / rangeT));
            const rgb = this.colormapTurbo(normT);
            colors.push(rgb[0], rgb[1], rgb[2]);
        }

        this.pointsCount = dataset.nodes.length;

        this.pointsPosBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, this.pointsPosBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);

        this.pointsColBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, this.pointsColBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(colors), gl.STATIC_DRAW);

        this.fitToView(dataset.bbox_min, dataset.bbox_max);
        this.render();
    }

    colormapTurbo(t) {
        // Warm thermal scale: mineral green -> brass -> amber -> terracotta.
        const stops = [
            [0.00, [0.34, 0.43, 0.32]],
            [0.35, [0.56, 0.61, 0.36]],
            [0.68, [0.83, 0.64, 0.31]],
            [1.00, [0.79, 0.36, 0.24]]
        ];
        const upper = stops.findIndex(([stop]) => stop >= t);
        const right = stops[Math.max(1, upper)];
        const left = stops[Math.max(0, upper - 1)];
        const fraction = (t - left[0]) / Math.max(1e-9, right[0] - left[0]);
        return left[1].map((channel, index) => channel + (right[1][index] - channel) * fraction);
    }

    fitToView(bboxMin, bboxMax) {
        if (!bboxMin || !bboxMax) return;
        const cx = (bboxMin.x + bboxMax.x) * 0.5;
        const cy = (bboxMin.y + bboxMax.y) * 0.5;
        const cz = (bboxMin.z + bboxMax.z) * 0.5;
        this.camera.target = [cx, cy, cz];

        const dx = bboxMax.x - bboxMin.x;
        const dy = bboxMax.y - bboxMin.y;
        const dz = bboxMax.z - bboxMin.z;
        const diag = Math.sqrt(dx * dx + dy * dy + dz * dz);
        this.camera.distance = Math.max(0.02, diag * 1.6);
        this.render();
    }

    setupControls() {
        let isDragging = false;
        let isPanning = false;
        let lastX = 0, lastY = 0;

        this.canvas.addEventListener('mousedown', (e) => {
            lastX = e.clientX;
            lastY = e.clientY;
            if (e.button === 2 || e.shiftKey) {
                isPanning = true;
            } else if (e.button === 0) {
                isDragging = true;
            }
        });

        window.addEventListener('mousemove', (e) => {
            const dx = e.clientX - lastX;
            const dy = e.clientY - lastY;
            lastX = e.clientX;
            lastY = e.clientY;

            if (isDragging) {
                this.camera.rotY += dx * 0.008;
                this.camera.rotX += dy * 0.008;
                this.camera.rotX = Math.max(-Math.PI / 2 + 0.01, Math.min(Math.PI / 2 - 0.01, this.camera.rotX));
                this.render();
            } else if (isPanning) {
                const panSpeed = this.camera.distance * 0.0015;
                const cosY = Math.cos(this.camera.rotY);
                const sinY = Math.sin(this.camera.rotY);
                this.camera.target[0] -= (dx * cosY) * panSpeed;
                this.camera.target[1] += dy * panSpeed;
                this.camera.target[2] -= (-dx * sinY) * panSpeed;
                this.render();
            } else if (this.mode === 'points' && this.ansysDataSet) {
                this.inspectNodeUnderMouse(e);
            }
        });

        window.addEventListener('mouseup', () => {
            isDragging = false;
            isPanning = false;
        });

        this.canvas.addEventListener('wheel', (e) => {
            e.preventDefault();
            const factor = e.deltaY > 0 ? 1.1 : 0.9;
            this.camera.distance *= factor;
            this.camera.distance = Math.max(0.005, Math.min(100.0, this.camera.distance));
            this.render();
        }, { passive: false });

        this.canvas.addEventListener('contextmenu', (e) => e.preventDefault());
    }

    inspectNodeUnderMouse(e) {
        if (!this.ansysDataSet || !this.tooltipEl) return;
        const rect = this.canvas.getBoundingClientRect();
        const mx = e.clientX - rect.left;
        const my = e.clientY - rect.top;

        if (mx < 0 || mx > rect.width || my < 0 || my > rect.height) {
            this.tooltipEl.style.display = 'none';
            return;
        }

        const mvp = this.computeMVPMatrix();
        let closestNode = null;
        let minDist = 18.0; // pixel threshold

        for (const n of this.ansysDataSet.nodes) {
            // Project (x, y, z) via MVP
            const sp = this.projectPoint(n[1], n[2], n[3], mvp, rect.width, rect.height);
            if (sp.z < 0 || sp.z > 1) continue;
            const dist = Math.hypot(mx - sp.x, my - sp.y);
            if (dist < minDist) {
                minDist = dist;
                closestNode = { id: n[0], x: n[1], y: n[2], z: n[3], temp: n[4], sx: sp.x, sy: sp.y };
            }
        }

        if (closestNode) {
            this.tooltipEl.style.display = 'block';
            this.tooltipEl.style.left = (rect.left + closestNode.sx + 15) + 'px';
            this.tooltipEl.style.top = (rect.top + closestNode.sy - 20) + 'px';
            this.tooltipEl.innerHTML = `
                <div style="font-weight:bold; color:#d8a36b;">Node ID: ${closestNode.id}</div>
                <div>X: ${closestNode.x.toFixed(4)} m</div>
                <div>Y: ${closestNode.y.toFixed(4)} m</div>
                <div>Z: ${closestNode.z.toFixed(4)} m</div>
                <div style="font-weight:bold; color:#f59e0b; margin-top:2px;">Temp: ${closestNode.temp.toFixed(2)} °C</div>
            `;
        } else {
            this.tooltipEl.style.display = 'none';
        }
    }

    projectPoint(x, y, z, m, width, height) {
        const px = m[0]*x + m[4]*y + m[8]*z + m[12];
        const py = m[1]*x + m[5]*y + m[9]*z + m[13];
        const pz = m[2]*x + m[6]*y + m[10]*z + m[14];
        const pw = m[3]*x + m[7]*y + m[11]*z + m[15];
        if (pw === 0) return { x: 0, y: 0, z: -1 };
        const ndcX = px / pw;
        const ndcY = py / pw;
        const ndcZ = pz / pw;
        return {
            x: (ndcX * 0.5 + 0.5) * width,
            y: (-ndcY * 0.5 + 0.5) * height,
            z: ndcZ
        };
    }

    resize() {
        const rect = this.canvas.parentElement.getBoundingClientRect();
        const dpr = window.devicePixelRatio || 1;
        this.width = rect.width || 800;
        this.height = rect.height || 500;
        this.canvas.width = this.width * dpr;
        this.canvas.height = this.height * dpr;
        this.gl.viewport(0, 0, this.canvas.width, this.canvas.height);
        this.render();
    }

    computeMVPMatrix() {
        const aspect = this.canvas.width / this.canvas.height;
        const pMat = this.perspectiveMatrix(this.camera.fov, aspect, 0.001, 100.0);

        // Camera position
        const cosX = Math.cos(this.camera.rotX), sinX = Math.sin(this.camera.rotX);
        const cosY = Math.cos(this.camera.rotY), sinY = Math.sin(this.camera.rotY);
        const eye = [
            this.camera.target[0] + this.camera.distance * sinY * cosX,
            this.camera.target[1] + this.camera.distance * sinX,
            this.camera.target[2] + this.camera.distance * cosY * cosX
        ];

        const vMat = this.lookAtMatrix(eye, this.camera.target, [0, 1, 0]);
        return this.multiplyMatrices(pMat, vMat);
    }

    render() {
        const gl = this.gl;
        gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

        const mvp = this.computeMVPMatrix();

        if (this.mode === 'stl' && this.stlPosBuffer) {
            gl.useProgram(this.stlProgram);
            const uMVP = gl.getUniformLocation(this.stlProgram, 'uMVP');
            const uModel = gl.getUniformLocation(this.stlProgram, 'uModel');
            const uColor = gl.getUniformLocation(this.stlProgram, 'uColor');
            const uLightDir = gl.getUniformLocation(this.stlProgram, 'uLightDir');

            gl.uniformMatrix4fv(uMVP, false, mvp);
            gl.uniformMatrix4fv(uModel, false, this.identityMatrix());
            gl.uniform3f(uColor, 0.78, 0.54, 0.32); // Warm brushed-copper surface

            // Light from camera orientation
            const lx = Math.sin(this.camera.rotY);
            const ly = 0.8;
            const lz = Math.cos(this.camera.rotY);
            const llen = Math.hypot(lx, ly, lz);
            gl.uniform3f(uLightDir, lx / llen, ly / llen, lz / llen);

            const aPos = gl.getAttribLocation(this.stlProgram, 'aPosition');
            gl.bindBuffer(gl.ARRAY_BUFFER, this.stlPosBuffer);
            gl.enableVertexAttribArray(aPos);
            gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 0, 0);

            const aNorm = gl.getAttribLocation(this.stlProgram, 'aNormal');
            gl.bindBuffer(gl.ARRAY_BUFFER, this.stlNormBuffer);
            gl.enableVertexAttribArray(aNorm);
            gl.vertexAttribPointer(aNorm, 3, gl.FLOAT, false, 0, 0);

            if (this.wireframe) {
                gl.drawArrays(gl.LINE_STRIP, 0, this.stlVertexCount);
            } else {
                gl.drawArrays(gl.TRIANGLES, 0, this.stlVertexCount);
            }
        } else if (this.mode === 'points' && this.pointsPosBuffer) {
            gl.useProgram(this.pointsProgram);
            const uMVP = gl.getUniformLocation(this.pointsProgram, 'uMVP');
            const uPointSize = gl.getUniformLocation(this.pointsProgram, 'uPointSize');
            gl.uniformMatrix4fv(uMVP, false, mvp);
            gl.uniform1f(uPointSize, 7.0 * (window.devicePixelRatio || 1));

            const aPos = gl.getAttribLocation(this.pointsProgram, 'aPosition');
            gl.bindBuffer(gl.ARRAY_BUFFER, this.pointsPosBuffer);
            gl.enableVertexAttribArray(aPos);
            gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 0, 0);

            const aCol = gl.getAttribLocation(this.pointsProgram, 'aColor');
            gl.bindBuffer(gl.ARRAY_BUFFER, this.pointsColBuffer);
            gl.enableVertexAttribArray(aCol);
            gl.vertexAttribPointer(aCol, 3, gl.FLOAT, false, 0, 0);

            gl.drawArrays(gl.POINTS, 0, this.pointsCount);
        }
    }

    // --- Matrix Math Helpers ---

    identityMatrix() {
        return new Float32Array([
            1, 0, 0, 0,
            0, 1, 0, 0,
            0, 0, 1, 0,
            0, 0, 0, 1
        ]);
    }

    perspectiveMatrix(fov, aspect, near, far) {
        const f = 1.0 / Math.tan(fov / 2);
        const rangeInv = 1.0 / (near - far);
        return new Float32Array([
            f / aspect, 0, 0, 0,
            0, f, 0, 0,
            0, 0, (near + far) * rangeInv, -1,
            0, 0, near * far * rangeInv * 2, 0
        ]);
    }

    lookAtMatrix(eye, target, up) {
        let z0 = eye[0] - target[0], z1 = eye[1] - target[1], z2 = eye[2] - target[2];
        let len = Math.hypot(z0, z1, z2);
        z0 /= len; z1 /= len; z2 /= len;

        let x0 = up[1] * z2 - up[2] * z1, x1 = up[2] * z0 - up[0] * z2, x2 = up[0] * z1 - up[1] * z0;
        len = Math.hypot(x0, x1, x2);
        x0 /= len; x1 /= len; x2 /= len;

        let y0 = z1 * x2 - z2 * x1, y1 = z2 * x0 - z0 * x2, y2 = z0 * x1 - z1 * x0;

        return new Float32Array([
            x0, y0, z0, 0,
            x1, y1, z1, 0,
            x2, y2, z2, 0,
            -(x0*eye[0] + x1*eye[1] + x2*eye[2]),
            -(y0*eye[0] + y1*eye[1] + y2*eye[2]),
            -(z0*eye[0] + z1*eye[1] + z2*eye[2]),
            1
        ]);
    }

    multiplyMatrices(a, b) {
        const out = new Float32Array(16);
        for (let i = 0; i < 4; ++i) {
            for (let j = 0; j < 4; ++j) {
                out[j * 4 + i] =
                    a[i] * b[j * 4] +
                    a[i + 4] * b[j * 4 + 1] +
                    a[i + 8] * b[j * 4 + 2] +
                    a[i + 12] * b[j * 4 + 3];
            }
        }
        return out;
    }
}

