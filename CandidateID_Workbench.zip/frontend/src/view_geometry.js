import { Renderer3D } from './renderer3d.js';
import { AppState } from './app.js';

let renderer = null;
let currentModel = null;

export function initGeometryView() {
    const canvas = document.getElementById('canvas-stl');
    if (!canvas) return;

    renderer = new Renderer3D('canvas-stl');

    const fileSelect = document.getElementById('stl-file-select');
    const fileInput = document.getElementById('stl-file-input');
    const parseBtn = document.getElementById('stl-parse-btn');
    const fitBtn = document.getElementById('stl-fit-btn');
    const wireBtn = document.getElementById('stl-wire-btn');

    fitBtn.addEventListener('click', () => {
        if (currentModel) {
            renderer.fitToView(currentModel.bbox_min, currentModel.bbox_max);
        }
    });

    wireBtn.addEventListener('click', () => {
        renderer.wireframe = !renderer.wireframe;
        renderer.render();
    });

    parseBtn.addEventListener('click', async () => {
        if (fileInput.files.length > 0) {
            const file = fileInput.files[0];
            if (file.size > 50 * 1024 * 1024) {
                AppState.showAlert('STL upload exceeds the 50 MB supported file limit. Choose a smaller ASCII STL file.', 'warning');
                AppState.setStatus('STL file exceeds the supported size limit', 'error');
                return;
            }
            const text = await file.text();
            parseSTLContent(text, file.name);
        } else {
            const path = fileSelect.value;
            parseSTLFilePath(path);
        }
    });

    fileInput.addEventListener('change', () => {
        if (fileInput.files.length > 0) {
            parseBtn.click();
        }
    });

    fileSelect.addEventListener('change', () => {
        fileInput.value = '';
        parseBtn.click();
    });

    window.addEventListener('resize', () => {
        const view = document.getElementById('view-geometry');
        if (view && view.classList.contains('active')) {
            renderer.resize();
        }
    });

    // Initial load of default sample
    parseSTLFilePath('samples/geometry/sample_heatsink.stl');
}

async function parseSTLFilePath(filepath) {
    AppState.setStatus(`Parsing STL file: ${filepath}...`, 'busy');
    try {
        const res = await fetch('/api/cad/stl/parse', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filepath })
        });
        const model = await res.json();
        handleSTLResult(model);
    } catch (err) {
        AppState.showAlert(`Network/Parsing Error: Failed to contact backend STL parser: ${err.message}`, 'error');
        AppState.setStatus('Error parsing STL', 'error');
    }
}

async function parseSTLContent(content, filename) {
    AppState.setStatus(`Parsing uploaded STL (${filename})...`, 'busy');
    try {
        const res = await fetch('/api/cad/stl/parse', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ raw_content: content })
        });
        const model = await res.json();
        handleSTLResult(model);
    } catch (err) {
        AppState.showAlert(`Parsing Error: ${err.message}`, 'error');
        AppState.setStatus('Error parsing STL', 'error');
    }
}

function handleSTLResult(model) {
    const metaCard = document.getElementById('stl-meta-card');
    if (!model.is_valid) {
        metaCard.style.display = 'none';
        AppState.showAlert(`STL Validation Rejection: ${model.error_message}`, 'error');
        AppState.setStatus('STL Validation Failed', 'error');
        return;
    }

    AppState.hideAlert();
    currentModel = model;
    metaCard.style.display = 'flex';

    document.getElementById('stl-meta-name').textContent = model.solid_name || 'unnamed';
    document.getElementById('stl-meta-triangles').textContent = model.triangle_count.toLocaleString();
    const dims = model.dimensions;
    document.getElementById('stl-meta-dims').textContent =
        `${(dims.x * 1000).toFixed(1)} x ${(dims.y * 1000).toFixed(1)} x ${(dims.z * 1000).toFixed(1)} mm`;
    document.getElementById('stl-meta-size').textContent =
        `${(model.file_size_bytes / 1024).toFixed(1)} KB`;

    renderer.setSTLModel(model);
    AppState.setStatus(`STL Parsed & Rendered: ${model.triangle_count} triangles`, 'ready');
}

