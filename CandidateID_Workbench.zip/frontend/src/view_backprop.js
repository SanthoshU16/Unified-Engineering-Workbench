import { CanvasChart } from './chart_engine.js';
import { AppState } from './app.js';

let lossChart = null;
let lastBackpropResult = null;

export function initBackpropView() {
    lossChart = new CanvasChart('canvas-backprop-loss', {
        title: 'Task F: Neural Network Mean Squared Error (Loss J) vs Training Step',
        xLabel: 'Training Step (Epoch)',
        yLabel: 'Loss J = 0.5 * (y_hat - y)² [Log Scale]',
        logY: true
    });

    const runBtn = document.getElementById('backprop-run-btn');
    const exportBtn = document.getElementById('backprop-export-btn');

    runBtn.addEventListener('click', runBackpropagation);
    exportBtn.addEventListener('click', exportBackpropCSV);

    window.addEventListener('resize', () => {
        const view = document.getElementById('view-backprop');
        if (view && view.classList.contains('active')) {
            lossChart.resize();
        }
    });

    // Auto-run initial evaluation
    runBackpropagation();
}

async function runBackpropagation() {
    AppState.setStatus('Computing Analytical Backpropagation & Central Finite Differences in C++...', 'busy');

    try {
        const res = await fetch('/api/backprop/run', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ learning_rate: 0.1, steps: 100 })
        });
        const data = await res.json();
        lastBackpropResult = data;
        updateBackpropUI(data);
        AppState.setStatus(`Backprop Verified: Central FD check PASSED (max err ${data.step0.fd_errors.w.toExponential(2)} <= 1e-5), Final Loss: ${data.history[data.history.length - 1].loss.toExponential(2)}`, 'ready');
    } catch (e) {
        AppState.showAlert(`Backprop calculation error: ${e.message}`, 'error');
        AppState.setStatus('Backpropagation error', 'error');
    }
}

function updateBackpropUI(data) {
    const s0 = data.step0;
    document.getElementById('bp-gw').textContent = s0.gradients.w.toFixed(8);
    document.getElementById('bp-gb').textContent = s0.gradients.b.toFixed(8);
    document.getElementById('bp-gv').textContent = s0.gradients.v.toFixed(8);
    document.getElementById('bp-gc').textContent = s0.gradients.c.toFixed(8);

    const fdStatus = document.getElementById('bp-fd-status');
    if (s0.fd_check_passed) {
        fdStatus.textContent = `PASSED (Max Error = ${Math.max(s0.fd_errors.w, s0.fd_errors.b, s0.fd_errors.v, s0.fd_errors.c).toExponential(2)} <= 1e-5)`;
        fdStatus.style.color = '#99b184';
    } else {
        fdStatus.textContent = `FAILED (> 1e-5)`;
        fdStatus.style.color = '#dc786c';
    }

    const lossSummary = document.getElementById('bp-loss-summary');
    lossSummary.textContent = `Step 0 Loss: ${s0.loss.toFixed(6)} → Step 100 Loss: ${data.history[data.history.length - 1].loss.toExponential(4)}`;

    // Populate Table
    const tbody = document.getElementById('bp-params-tbody');
    tbody.innerHTML = `
        <tr>
            <td style="font-weight:bold; color:#d8a36b;">Weight w</td>
            <td>${data.initial.w.toFixed(4)}</td>
            <td style="color:#e0b564;">${s0.gradients.w.toFixed(8)}</td>
            <td>${s0.finite_diff.w.toFixed(8)}</td>
            <td style="color:#99b184;">${s0.fd_errors.w.toExponential(3)}</td>
            <td style="font-weight:bold; color:#f1f5f9;">${data.step1.w.toFixed(8)}</td>
        </tr>
        <tr>
            <td style="font-weight:bold; color:#d8a36b;">Bias b</td>
            <td>${data.initial.b.toFixed(4)}</td>
            <td style="color:#e0b564;">${s0.gradients.b.toFixed(8)}</td>
            <td>${s0.finite_diff.b.toFixed(8)}</td>
            <td style="color:#99b184;">${s0.fd_errors.b.toExponential(3)}</td>
            <td style="font-weight:bold; color:#f1f5f9;">${data.step1.b.toFixed(8)}</td>
        </tr>
        <tr>
            <td style="font-weight:bold; color:#d8a36b;">Weight v</td>
            <td>${data.initial.v.toFixed(4)}</td>
            <td style="color:#e0b564;">${s0.gradients.v.toFixed(8)}</td>
            <td>${s0.finite_diff.v.toFixed(8)}</td>
            <td style="color:#99b184;">${s0.fd_errors.v.toExponential(3)}</td>
            <td style="font-weight:bold; color:#f1f5f9;">${data.step1.v.toFixed(8)}</td>
        </tr>
        <tr>
            <td style="font-weight:bold; color:#d8a36b;">Bias c</td>
            <td>${data.initial.c.toFixed(4)}</td>
            <td style="color:#e0b564;">${s0.gradients.c.toFixed(8)}</td>
            <td>${s0.finite_diff.c.toFixed(8)}</td>
            <td style="color:#99b184;">${s0.fd_errors.c.toExponential(3)}</td>
            <td style="font-weight:bold; color:#f1f5f9;">${data.step1.c.toFixed(8)}</td>
        </tr>
    `;

    // Render Loss Chart
    const lossData = data.history.map(h => ({ x: h.step, y: Math.max(1e-15, h.loss) }));
    lossChart.setSeries([
        { label: 'Loss J = 0.5 * (y_hat - y)²', data: lossData, color: '#d8a36b', lineWidth: 2, pointRadius: 3 }
    ]);

    document.getElementById('backprop-export-btn').style.display = 'inline-flex';
}

function exportBackpropCSV() {
    if (!lastBackpropResult) return;
    const res = lastBackpropResult;
    let csv = `# Unified Engineering Workbench - Task F Backpropagation Training Loss\n`;
    csv += `# Architecture: h = tanh(w*x + b), y_hat = v*h + c, loss = 0.5*(y_hat - y)^2\n`;
    csv += `# Initial: x=${res.initial.x}, y=${res.initial.y}, w=${res.initial.w}, b=${res.initial.b}, v=${res.initial.v}, c=${res.initial.c}, lr=${res.initial.learning_rate}\n`;
    csv += `step,w,b,v,c,y_hat,loss,grad_w,grad_b,grad_v,grad_c\n`;

    res.history.forEach(s => {
        csv += `${s.step},${s.w},${s.b},${s.v},${s.c},${s.y_hat},${s.loss},${s.grad_w},${s.grad_b},${s.grad_v},${s.grad_c}\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `backprop_training_100steps.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

