import { AppState } from './app.js';

const devices = ['mcu', 'fpga', 'jtag'];
const deviceIds = {
    'mcu': 'mcu_stm32f4',
    'fpga': 'fpga_artix7',
    'jtag': 'jtag_probe'
};

const pollIntervals = {};

export function initHardwareView() {
    devices.forEach(dev => {
        const devId = deviceIds[dev];

        const btnConnect = document.getElementById(`btn-connect-${dev}`);
        const btnCaps = document.getElementById(`btn-caps-${dev}`);
        const btnFail = document.getElementById(`btn-fail-${dev}`);
        const btnRecover = document.getElementById(`btn-recover-${dev}`);

        btnConnect.addEventListener('click', async () => {
            const isConnected = btnConnect.textContent === 'Disconnect';
            const action = isConnected ? 'disconnect' : 'connect';
            const res = await callEmbeddedAction(devId, action);
            if (res) {
                if (action === 'connect') {
                    btnConnect.textContent = 'Disconnect';
                    btnConnect.className = 'btn btn-sm btn-danger';
                    updateBadge(dev, 'connected', 'CONNECTED');
                    startTelemetry(dev);
                } else {
                    btnConnect.textContent = 'Connect';
                    btnConnect.className = 'btn btn-sm btn-primary';
                    updateBadge(dev, 'disconnected', 'DISCONNECTED');
                    stopTelemetry(dev);
                    document.getElementById(`telemetry-${dev}`).textContent = "Device disconnected.";
                }
            }
        });

        btnCaps.addEventListener('click', async () => {
            const data = await callEmbeddedAction(devId, 'capabilities');
            if (data) {
                document.getElementById(`telemetry-${dev}`).textContent = JSON.stringify(data, null, 2);
            }
        });

        btnFail.addEventListener('click', async () => {
            AppState.showAlert(`Simulating recoverable timeout on ${dev.toUpperCase()} interface...`, 'warning');
            const data = await callEmbeddedAction(devId, 'inject_failure');
            if (data) {
                updateBadge(dev, 'error', 'ERROR_TIMEOUT');
                document.getElementById(`telemetry-${dev}`).textContent =
                    `[ALERT] Communication timeout detected!\nDeadline 250ms exceeded without ACK.\nInterface suspended. Click 'Auto-Recover' to restore.`;
            }
        });

        btnRecover.addEventListener('click', async () => {
            const data = await callEmbeddedAction(devId, 'recover');
            if (data && data.recovered) {
                AppState.hideAlert();
                updateBadge(dev, 'streaming', 'STREAMING');
                document.getElementById(`telemetry-${dev}`).textContent =
                    `[RECOVERY] Interface re-handshake successful.\nBuffers cleared, clocks resynchronized.\nResuming normal telemetry stream.`;
            }
        });
    });
}

function updateBadge(dev, stateClass, text) {
    const badge = document.getElementById(`badge-${dev}`);
    badge.className = `device-badge ${stateClass}`;
    badge.textContent = text;
}

function startTelemetry(dev) {
    stopTelemetry(dev);
    const devId = deviceIds[dev];
    pollIntervals[dev] = setInterval(async () => {
        try {
            const res = await callEmbeddedAction(devId, 'telemetry');
            if (res) {
                const box = document.getElementById(`telemetry-${dev}`);
                if (res.status === 'ERROR_TIMEOUT') {
                    updateBadge(dev, 'error', 'ERROR_TIMEOUT');
                    box.textContent = `[ERROR TIMEOUT] ${res.error}`;
                } else {
                    updateBadge(dev, 'streaming', 'STREAMING');
                    box.textContent = JSON.stringify(res, null, 2);
                }
            }
        } catch (e) {
            // ignore network jitter during tab switch
        }
    }, 1200);
}

function stopTelemetry(dev) {
    if (pollIntervals[dev]) {
        clearInterval(pollIntervals[dev]);
        delete pollIntervals[dev];
    }
}

async function callEmbeddedAction(deviceId, action) {
    try {
        const res = await fetch('/api/embedded/action', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ device_id: deviceId, action })
        });
        return await res.json();
    } catch (e) {
        AppState.showAlert(`Embedded subsystem communication error: ${e.message}`, 'error');
        return null;
    }
}

