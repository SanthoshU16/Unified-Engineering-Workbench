import { CanvasChart } from './chart_engine.js';
import { Renderer3D } from './renderer3d.js';
import { AppState } from './app.js';

let feaPlot = null;
let convPlot = null;
let ansysRenderer = null;
let lastFEAResult = null;

export function initThermalView() {
    const modeSelect = document.getElementById('thermal-mode-select');
    const feaPanel = document.getElementById('fea-controls-panel');
    const ansysPanel = document.getElementById('ansys-controls-panel');
    const feaDisplay = document.getElementById('fea-display-area');
    const ansysDisplay = document.getElementById('ansys-display-area');

    modeSelect.addEventListener('change', () => {
        if (modeSelect.value === 'fea') {
            feaPanel.style.display = 'flex';
            ansysPanel.style.display = 'none';
            feaDisplay.style.display = 'flex';
            ansysDisplay.style.display = 'none';
            if (feaPlot) feaPlot.resize();
            if (convPlot) convPlot.resize();
        } else {
            feaPanel.style.display = 'none';
            ansysPanel.style.display = 'flex';
            feaDisplay.style.display = 'none';
            ansysDisplay.style.display = 'flex';
            if (!ansysRenderer) {
                initANSYSRenderer();
            } else {
                ansysRenderer.resize();
            }
        }
    });

    // --- 1D FEA Initialization ---
    initFEASolver();

    // --- ANSYS Initialization ---
    initANSYSControls();

    window.addEventListener('resize', () => {
        const view = document.getElementById('view-thermal');
        if (view && view.classList.contains('active')) {
            if (modeSelect.value === 'fea') {
                if (feaPlot) feaPlot.resize();
                if (convPlot) convPlot.resize();
            } else if (ansysRenderer) {
                ansysRenderer.resize();
            }
        }
    });
}

function initFEASolver() {
    feaPlot = new CanvasChart('canvas-fea-plot', {
        title: 'Temperature Distribution T(x) Along 1D Insulated Rod',
        xLabel: 'Rod Position x (m)',
        yLabel: 'Temperature T (°C)'
    });

    convPlot = new CanvasChart('canvas-convergence-plot', {
        title: 'Mesh Convergence Analysis (Midpoint Error vs Element Size h)',
        xLabel: 'Mesh Element Length h (m) [Log Scale]',
        yLabel: 'Max Absolute Midpoint Error (°C) [Log Scale]',
        logX: true,
        logY: true
    });

    const solveBtn = document.getElementById('fea-solve-btn');
    const exportBtn = document.getElementById('fea-export-btn');

    solveBtn.addEventListener('click', runFEASolve);
    exportBtn.addEventListener('click', exportFEACSV);

    // Initial FEA solve
    runFEASolve();
}

async function runFEASolve() {
    const L = parseFloat(document.getElementById('fea-input-L').value);
    const A = parseFloat(document.getElementById('fea-input-A').value);
    const k = parseFloat(document.getElementById('fea-input-k').value);
    const q = parseFloat(document.getElementById('fea-input-q').value);
    const T0 = parseFloat(document.getElementById('fea-input-T0').value);
    const TL = parseFloat(document.getElementById('fea-input-TL').value);
    const N = parseInt(document.getElementById('fea-input-N').value);

    // Frontend validation
    if (L <= 0 || A <= 0 || k <= 0 || N < 1) {
        AppState.showAlert('Parameter Validation Error: Length L, Area A, and Conductivity k must be strictly positive; Elements N >= 1.', 'warning');
        return;
    }

    AppState.setStatus('Solving 1D Thermal FEA & Convergence in C++...', 'busy');

    try {
        const res = await fetch('/api/fea/solve', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ L, A, k, q, T0, TL, num_elements: N })
        });
        const data = await res.json();

        if (!data.success) {
            AppState.showAlert(`FEA Solver Error: ${data.error_message}`, 'error');
            AppState.setStatus('FEA solve failed', 'error');
            return;
        }

        AppState.hideAlert();
        lastFEAResult = data;
        updateFEAChartsAndTable(data);
        AppState.setStatus(`FEA Solved: N=${N}, Max Midpoint Error=${data.max_midpoint_error.toFixed(6)} °C, Max Nodal Error=${data.max_nodal_error.toExponential(2)} °C`, 'ready');
    } catch (e) {
        AppState.showAlert(`Failed to run FEA solver: ${e.message}`, 'error');
        AppState.setStatus('FEA error', 'error');
    }
}

function updateFEAChartsAndTable(data) {
    // 1. FEA vs Exact Plot
    const exactSeries = [];
    const numFine = 100;
    const L = data.config.L, T0 = data.config.T0, TL = data.config.TL, k = data.config.k, q = data.config.q;
    for (let i = 0; i <= numFine; ++i) {
        const x = (i / numFine) * L;
        const T_ex = T0 + (TL - T0) * (x / L) + (q / (2 * k)) * x * (L - x);
        exactSeries.push({ x, y: T_ex });
    }

    const feaSeries = data.nodes.map(n => ({ x: n.x, y: n.T_fea }));

    feaPlot.setSeries([
        { label: 'Exact Analytical T_exact(x)', data: exactSeries, color: '#d8a36b', lineWidth: 2, showPoints: false },
        { label: `FEA Discrete Nodes (N=${data.config.num_elements})`, data: feaSeries, color: '#e0b564', lineWidth: 1.5, pointRadius: 4.5, showPoints: true }
    ]);

    // 2. Convergence Plot (Midpoint Error vs h)
    if (data.convergence && data.convergence.length > 0) {
        const convData = data.convergence.map(c => ({ x: c.h, y: c.max_midpoint_error }));
        const theoryData = data.convergence.map(c => ({ x: c.h, y: c.theoretical_error }));

        convPlot.setSeries([
            { label: 'Empirical Midpoint Error', data: convData, color: '#99b184', lineWidth: 2, pointRadius: 5 },
            { label: 'Theoretical O(h²) Bound [q/(8k)]*h²', data: theoryData, color: '#ec4899', lineWidth: 1.5, dash: [4, 4], pointRadius: 4 }
        ]);

        // 3. Update Table
        const tbody = document.getElementById('fea-conv-tbody');
        tbody.innerHTML = '';
        data.convergence.forEach(c => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td style="font-weight:bold; color:#f1f5f9;">${c.N}</td>
                <td>${c.h.toFixed(4)}</td>
                <td style="color:#d8a36b;">${c.max_midpoint_error.toFixed(8)}</td>
                <td style="color:#ec4899;">${c.theoretical_error.toFixed(8)}</td>
                <td style="font-weight:bold; color:#99b184;">${c.convergence_rate > 0 ? c.convergence_rate.toFixed(3) : 'Base (Ref)'}</td>
            `;
            tbody.appendChild(tr);
        });
    }
}

function exportFEACSV() {
    if (!lastFEAResult) return;
    const cfg = lastFEAResult.config;
    let csv = `# Unified Engineering Workbench - 1D Thermal FEA Results\n`;
    csv += `# L=${cfg.L}m, A=${cfg.A}m2, k=${cfg.k}W/(m K), q=${cfg.q}W/m3, T0=${cfg.T0}C, TL=${cfg.TL}C, N=${cfg.num_elements}\n`;
    csv += `type,x_m,T_fea_C,T_exact_C,absolute_error_C\n`;

    lastFEAResult.nodes.forEach(n => {
        const T_ex = cfg.T0 + (cfg.TL - cfg.T0) * (n.x / cfg.L) + (cfg.q / (2 * cfg.k)) * n.x * (cfg.L - n.x);
        csv += `node,${n.x.toFixed(6)},${n.T_fea.toFixed(6)},${T_ex.toFixed(6)},${Math.abs(n.T_fea - T_ex).toExponential(4)}\n`;
    });

    lastFEAResult.midpoints.forEach(m => {
        csv += `midpoint,${m.x.toFixed(6)},${m.T_fea.toFixed(6)},${m.T_exact.toFixed(6)},${m.error.toFixed(6)}\n`;
    });

    downloadBlob(csv, `fea_thermal_N${cfg.num_elements}_results.csv`, 'text/csv');
}

// --- ANSYS 3D Point Cloud Implementation ---

function initANSYSRenderer() {
    ansysRenderer = new Renderer3D('canvas-ansys');
    ansysRenderer.setTooltipElement(document.getElementById('node-tooltip'));
    parseANSYSFilePath('samples/thermal/ansys_nodal_temperature.csv');
}

function initANSYSControls() {
    const fileSelect = document.getElementById('ansys-file-select');
    const fileInput = document.getElementById('ansys-file-input');
    const parseBtn = document.getElementById('ansys-parse-btn');

    parseBtn.addEventListener('click', async () => {
        if (!ansysRenderer) initANSYSRenderer();
        if (fileInput.files.length > 0) {
            const file = fileInput.files[0];
            if (file.size > 50 * 1024 * 1024) {
                AppState.showAlert('CSV upload exceeds the 50 MB supported file limit. Choose a smaller nodal export.', 'warning');
                AppState.setStatus('ANSYS CSV exceeds the supported size limit', 'error');
                return;
            }
            const text = await file.text();
            parseANSYSContent(text, file.name);
        } else {
            parseANSYSFilePath(fileSelect.value);
        }
    });

    fileInput.addEventListener('change', () => {
        if (fileInput.files.length > 0) parseBtn.click();
    });

    fileSelect.addEventListener('change', () => {
        fileInput.value = '';
        parseBtn.click();
    });
}

async function parseANSYSFilePath(filepath) {
    AppState.setStatus(`Parsing ANSYS CSV: ${filepath}...`, 'busy');
    try {
        const res = await fetch('/api/cad/ansys/parse', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filepath })
        });
        const dataset = await res.json();
        handleANSYSResult(dataset);
    } catch (e) {
        AppState.showAlert(`Failed to parse ANSYS CSV: ${e.message}`, 'error');
        AppState.setStatus('Error parsing ANSYS CSV', 'error');
    }
}

async function parseANSYSContent(content, filename) {
    AppState.setStatus(`Parsing uploaded ANSYS CSV (${filename})...`, 'busy');
    try {
        const res = await fetch('/api/cad/ansys/parse', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ raw_content: content })
        });
        const dataset = await res.json();
        handleANSYSResult(dataset);
    } catch (e) {
        AppState.showAlert(`Error parsing ANSYS CSV: ${e.message}`, 'error');
        AppState.setStatus('Error parsing ANSYS CSV', 'error');
    }
}

function handleANSYSResult(dataset) {
    const metaCard = document.getElementById('ansys-meta-card');
    if (!dataset.is_valid) {
        metaCard.style.display = 'none';
        AppState.showAlert(`ANSYS CSV Validation Rejection: ${dataset.error_message}`, 'error');
        AppState.setStatus('ANSYS CSV Validation Failed', 'error');
        return;
    }

    AppState.hideAlert();
    metaCard.style.display = 'flex';
    document.getElementById('ansys-meta-nodes').textContent = dataset.node_count.toLocaleString();
    document.getElementById('ansys-meta-range').textContent =
        `${dataset.min_temperature.toFixed(2)} °C to ${dataset.max_temperature.toFixed(2)} °C`;
    document.getElementById('ansys-meta-mean').textContent =
        `${dataset.mean_temperature.toFixed(2)} °C`;

    document.getElementById('legend-min-temp').textContent = `${dataset.min_temperature.toFixed(1)} °C`;
    document.getElementById('legend-mid-temp').textContent = `${((dataset.min_temperature + dataset.max_temperature) / 2).toFixed(1)} °C`;
    document.getElementById('legend-max-temp').textContent = `${dataset.max_temperature.toFixed(1)} °C`;

    ansysRenderer.setANSYSDataSet(dataset);
    AppState.setStatus(`ANSYS 3D Point Cloud Rendered: ${dataset.node_count} nodes`, 'ready');
}

function downloadBlob(content, filename, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

