import { CanvasChart } from './chart_engine.js';
import { AppState } from './app.js';

let speedupChart = null;
let lastBenchmarkResult = null;

export function initPerformanceView() {
    speedupChart = new CanvasChart('canvas-bench-speedup', {
        title: 'CPU Worker Scaling: Execution Time (ms) & Speedup Ratio (T1/Tp)',
        xLabel: 'CPU Worker Threads',
        yLabel: 'Median Compute Time (ms)'
    });

    const runBtn = document.getElementById('bench-run-btn');
    const exportBtn = document.getElementById('bench-export-btn');

    runBtn.addEventListener('click', runBenchmark);
    exportBtn.addEventListener('click', exportBenchmarkCSV);

    window.addEventListener('resize', () => {
        const view = document.getElementById('view-performance');
        if (view && view.classList.contains('active')) {
            speedupChart.resize();
        }
    });

    // Auto-run initial benchmark
    runBenchmark();
}

async function runBenchmark() {
    const num_cases = parseInt(document.getElementById('bench-cases').value);
    const mesh_size = parseInt(document.getElementById('bench-mesh').value);
    const seed = parseInt(document.getElementById('bench-seed').value);

    if (num_cases < 10 || mesh_size < 5) {
        AppState.showAlert('Benchmark Validation: Cases must be >= 10, mesh size >= 5.', 'warning');
        return;
    }

    AppState.setStatus(`Executing Multicore Benchmark (${num_cases} cases, mesh ${mesh_size}, 5 reps)...`, 'busy');
    AppState.setWorkload('Multicore C++ Pool Running');

    const runBtn = document.getElementById('bench-run-btn');
    runBtn.disabled = true;
    runBtn.textContent = 'Running Benchmark (C++ Threads)...';

    try {
        const res = await fetch('/api/benchmark/run', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ num_cases, mesh_size, seed, repetitions: 5 })
        });
        const data = await res.json();
        lastBenchmarkResult = data;
        updateBenchmarkResults(data);
        AppState.setStatus(`Benchmark Completed: Verification ${data.verification_passed ? 'PASSED' : 'FAILED'} (Max Diff: ${data.serial_parallel_max_diff.toExponential(2)} °C)`, 'ready');
        AppState.setWorkload('Idle');
    } catch (e) {
        AppState.showAlert(`Benchmark error: ${e.message}`, 'error');
        AppState.setStatus('Benchmark failed', 'error');
        AppState.setWorkload('Error');
    } finally {
        runBtn.disabled = false;
        runBtn.textContent = 'Run Parallel Benchmark (C++)';
    }
}

function updateBenchmarkResults(data) {
    // 1. Agreement Badge
    const badge = document.getElementById('bench-agreement-badge');
    badge.style.display = 'inline-block';
    if (data.verification_passed) {
        badge.style.background = 'rgba(16, 185, 129, 0.2)';
        badge.style.color = '#99b184';
        badge.style.border = '1px solid rgba(16, 185, 129, 0.4)';
        badge.textContent = `Agreement: PASS (Max Diff = ${data.serial_parallel_max_diff.toExponential(2)} °C <= 1e-8)`;
    } else {
        badge.style.background = 'rgba(239, 68, 68, 0.2)';
        badge.style.color = '#dc786c';
        badge.style.border = '1px solid rgba(239, 68, 68, 0.4)';
        badge.textContent = `Agreement: FAIL (Max Diff = ${data.serial_parallel_max_diff.toExponential(2)} °C > 1e-8)`;
    }

    // 2. Hardware display
    const hwLaunch = document.getElementById('hw-launch');
    if (hwLaunch) hwLaunch.textContent = `${data.launch_to_ready_ms.toFixed(1)} ms`;

    // 3. Results Table
    const tbody = document.getElementById('bench-results-tbody');
    tbody.innerHTML = '';
    data.measurements.forEach(m => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td style="font-weight:bold; color:#f1f5f9;">${m.workers} Worker${m.workers > 1 ? 's' : ''}</td>
            <td>${m.run_times_ms[0]?.toFixed(2) || '-'}</td>
            <td>${m.run_times_ms[1]?.toFixed(2) || '-'}</td>
            <td>${m.run_times_ms[2]?.toFixed(2) || '-'}</td>
            <td>${m.run_times_ms[3]?.toFixed(2) || '-'}</td>
            <td>${m.run_times_ms[4]?.toFixed(2) || '-'}</td>
            <td style="font-weight:bold; color:#d8a36b;">${m.median_time_ms.toFixed(2)}</td>
            <td style="font-weight:bold; color:#e0b564;">${m.speedup.toFixed(2)}x</td>
            <td style="color:#99b184;">${(m.efficiency * 100).toFixed(1)}%</td>
        `;
        tbody.appendChild(tr);
    });

    // 4. Update Chart
    const timeData = data.measurements.map(m => ({ x: m.workers, y: m.median_time_ms }));
    speedupChart.setSeries([
        { label: 'Median Wall-Clock Time (ms)', data: timeData, color: '#d8a36b', lineWidth: 2.5, pointRadius: 5 }
    ]);

    // Show export button
    document.getElementById('bench-export-btn').style.display = 'inline-flex';
}

function exportBenchmarkCSV() {
    if (!lastBenchmarkResult) return;
    const res = lastBenchmarkResult;
    let csv = `# Unified Engineering Workbench - Multicore Thermal Benchmark\n`;
    csv += `# CPU: ${res.cpu_model} | Cores: ${res.logical_cpus} | Compiler: ${res.compiler_info} | Flags: ${res.optimization_flags}\n`;
    csv += `# Physical Cores: ${res.physical_cpus}, Logical Cores: ${res.logical_cpus}\n`;
    csv += `# Cases: ${res.config.num_cases}, Mesh: ${res.config.mesh_size}, Seed: ${res.config.seed}\n`;
    csv += `# Serial/Parallel Diff: ${res.serial_parallel_max_diff} C (Pass: ${res.verification_passed ? 'YES' : 'NO'})\n`;
    csv += `workers,rep1_ms,rep2_ms,rep3_ms,rep4_ms,rep5_ms,median_ms,speedup,efficiency\n`;

    res.measurements.forEach(m => {
        csv += `${m.workers},${m.run_times_ms.join(',')},${m.median_time_ms},${m.speedup},${m.efficiency}\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `benchmark_multicore_${res.config.num_cases}cases.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

