import { initGeometryView } from './view_geometry.js';
import { initThermalView } from './view_thermal.js';
import { initPerformanceView } from './view_performance.js';
import { initHardwareView } from './view_hardware.js';
import { initBackpropView } from './view_backprop.js';

export class AppState {
    static showAlert(message, type = 'error') {
        const banner = document.getElementById('alert-banner');
        const msg = document.getElementById('alert-message');
        msg.textContent = message;
        banner.className = type;
        banner.style.display = 'flex';
    }

    static hideAlert() {
        const banner = document.getElementById('alert-banner');
        banner.style.display = 'none';
    }

    static setStatus(text, state = 'ready') {
        const statusText = document.getElementById('global-status-text');
        const dot = document.getElementById('global-status-dot');
        const railText = document.getElementById('rail-status-text');
        const railDot = document.getElementById('rail-status-dot');
        statusText.textContent = text;
        const statusClass = 'status-dot' + (state === 'busy' ? ' busy' : (state === 'error' ? ' error' : ''));
        dot.className = statusClass;
        if (railDot) railDot.className = statusClass;
        if (railText) {
            railText.textContent = state === 'error' ? 'Engine needs attention' :
                state === 'busy' ? 'Core processing' :
                    text.includes('Offline') ? 'Static preview mode' : 'C++ core connected';
        }
    }

    static setWorkload(text) {
        const wl = document.getElementById('global-workload-text');
        wl.textContent = text;
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    const viewMeta = {
        geometry: ['CAD Geometry', 'Import, inspect, and validate ASCII STL models.'],
        thermal: ['Thermal Analysis', 'Solve a conduction model or inspect nodal temperature data.'],
        performance: ['Performance Lab', 'Measure deterministic serial and parallel workloads.'],
        hardware: ['Embedded Workbench', 'Explore target interfaces, telemetry, and recovery states.'],
        backprop: ['Backpropagation Lab', 'Inspect analytical gradients and training convergence.']
    };

    // Alert close button
    document.getElementById('alert-close-btn').addEventListener('click', () => {
        AppState.hideAlert();
    });

    // Tab navigation
    const tabButtons = document.querySelectorAll('.tab-btn');
    const viewContainers = document.querySelectorAll('.view-container');

    const activateView = (target, persist = true) => {
        if (!viewMeta[target]) return;
        tabButtons.forEach(btn => {
            const selected = btn.getAttribute('data-tab') === target;
            btn.classList.toggle('active', selected);
            if (selected) btn.setAttribute('aria-current', 'page');
            else btn.removeAttribute('aria-current');
        });
        viewContainers.forEach(view => view.classList.toggle('active', view.id === `view-${target}`));
        document.getElementById('workspace-title').textContent = viewMeta[target][0];
        document.getElementById('workspace-description').textContent = viewMeta[target][1];
        if (persist) {
            try { localStorage.setItem('uew.activeView', target); } catch (_) { /* storage is optional */ }
        }
        window.dispatchEvent(new Event('resize'));
    };

    tabButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            activateView(btn.getAttribute('data-tab'));
        });
    });

    try {
        const lastView = localStorage.getItem('uew.activeView');
        if (viewMeta[lastView]) activateView(lastView, false);
    } catch (_) { /* storage is optional */ }

    // Query system info from backend
    try {
        const res = await fetch('/api/system/info');
        if (res.ok) {
            const info = await res.json();
            AppState.setStatus(`Backend Core Online (${info.compiler}, ${info.platform}) | Port: ${info.server_port}`, 'ready');
            const hwCpu = document.getElementById('hw-cpu');
            const hwCores = document.getElementById('hw-cores');
            const hwComp = document.getElementById('hw-compiler');
            const hwFlags = document.getElementById('hw-flags');
            if (hwCpu) hwCpu.textContent = info.cpu_model || info.platform;
            if (hwCores) hwCores.textContent = `${info.logical_cpus} Logical (${info.physical_cpus} Physical)`;
            if (hwComp) hwComp.textContent = info.compiler;
            if (hwFlags) hwFlags.textContent = "-O3 / Release";
        }
    } catch (e) {
        AppState.setStatus("Operating in Standalone Static Mode (Backend API offline)", "busy");
    }

    // Initialize all views
    initGeometryView();
    initThermalView();
    initPerformanceView();
    initHardwareView();
    initBackpropView();
});

