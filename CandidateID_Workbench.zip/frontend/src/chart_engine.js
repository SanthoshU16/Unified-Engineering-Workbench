// Lightweight, zero-dependency interactive 2D Canvas Charting Engine
// Supports multi-series line charts, log-log scaling, and bar charts with hover tooltips

export class CanvasChart {
    constructor(canvasId, options = {}) {
        this.canvas = document.getElementById(canvasId);
        if (!this.canvas) throw new Error(`Canvas #${canvasId} not found`);
        this.ctx = this.canvas.getContext('2d');
        this.options = Object.assign({
            title: '',
            xLabel: 'X',
            yLabel: 'Y',
            logX: false,
            logY: false,
            showLegend: true,
            padding: { top: 35, right: 30, bottom: 45, left: 65 }
        }, options);

        this.series = [];
        this.hoverPoint = null;
        this.setupEventHandlers();
        this.resize();
    }

    resize() {
        const rect = this.canvas.parentElement.getBoundingClientRect();
        const dpr = window.devicePixelRatio || 1;
        this.width = rect.width || 600;
        this.height = rect.height || 300;
        this.canvas.width = this.width * dpr;
        this.canvas.height = this.height * dpr;
        this.canvas.style.width = this.width + 'px';
        this.canvas.style.height = this.height + 'px';
        this.ctx.scale(dpr, dpr);
        this.render();
    }

    setSeries(seriesArray) {
        this.series = seriesArray;
        this.render();
    }

    setupEventHandlers() {
        this.canvas.addEventListener('mousemove', (e) => {
            const rect = this.canvas.getBoundingClientRect();
            const mouseX = e.clientX - rect.left;
            const mouseY = e.clientY - rect.top;
            this.handleMouseMove(mouseX, mouseY);
        });
        this.canvas.addEventListener('mouseleave', () => {
            this.hoverPoint = null;
            this.render();
        });
    }

    handleMouseMove(mx, my) {
        const pad = this.options.padding;
        const plotW = this.width - pad.left - pad.right;
        const plotH = this.height - pad.top - pad.bottom;
        if (mx < pad.left || mx > pad.left + plotW || my < pad.top || my > pad.top + plotH) {
            if (this.hoverPoint) {
                this.hoverPoint = null;
                this.render();
            }
            return;
        }

        let closest = null;
        let minDist = 15;

        for (const s of this.series) {
            for (const pt of s.data) {
                const px = this.xToScreen(pt.x);
                const py = this.yToScreen(pt.y);
                const dist = Math.hypot(mx - px, my - py);
                if (dist < minDist) {
                    minDist = dist;
                    closest = { x: pt.x, y: pt.y, px, py, label: s.label || '', color: s.color || '#d8a36b' };
                }
            }
        }

        this.hoverPoint = closest;
        this.render();
    }

    computeBounds() {
        let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
        for (const s of this.series) {
            for (const pt of s.data) {
                if (pt.x < minX) minX = pt.x;
                if (pt.x > maxX) maxX = pt.x;
                if (pt.y < minY) minY = pt.y;
                if (pt.y > maxY) maxY = pt.y;
            }
        }
        if (minX === Infinity) { minX = 0; maxX = 1; minY = 0; maxY = 1; }
        if (minX === maxX) { minX -= 1; maxX += 1; }
        if (minY === maxY) { minY -= 1; maxY += 1; }

        if (!this.options.logY && minY > 0 && minY < maxY * 0.2) minY = 0;
        this.bounds = { minX, maxX, minY, maxY };
    }

    xToScreen(x) {
        const pad = this.options.padding;
        const w = this.width - pad.left - pad.right;
        if (this.options.logX) {
            const lx = Math.log10(Math.max(1e-12, x));
            const lmin = Math.log10(Math.max(1e-12, this.bounds.minX));
            const lmax = Math.log10(Math.max(1e-12, this.bounds.maxX));
            return pad.left + ((lx - lmin) / (lmax - lmin)) * w;
        }
        return pad.left + ((x - this.bounds.minX) / (this.bounds.maxX - this.bounds.minX)) * w;
    }

    yToScreen(y) {
        const pad = this.options.padding;
        const h = this.height - pad.top - pad.bottom;
        if (this.options.logY) {
            const ly = Math.log10(Math.max(1e-12, y));
            const lmin = Math.log10(Math.max(1e-12, this.bounds.minY));
            const lmax = Math.log10(Math.max(1e-12, this.bounds.maxY));
            return pad.top + h - ((ly - lmin) / (lmax - lmin)) * h;
        }
        return pad.top + h - ((y - this.bounds.minY) / (this.bounds.maxY - this.bounds.minY)) * h;
    }

    render() {
        const ctx = this.ctx;
        ctx.clearRect(0, 0, this.width, this.height);

        this.computeBounds();
        const pad = this.options.padding;
        const plotW = this.width - pad.left - pad.right;
        const plotH = this.height - pad.top - pad.bottom;

        // Background
        ctx.fillStyle = '#191d18';
        ctx.fillRect(0, 0, this.width, this.height);
        ctx.fillStyle = '#141713';
        ctx.fillRect(pad.left, pad.top, plotW, plotH);

        // Title
        if (this.options.title) {
            ctx.fillStyle = '#eeece3';
            ctx.font = 'bold 13px -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif';
            ctx.textAlign = 'left';
            ctx.fillText(this.options.title, pad.left, 22);
        }

        // Gridlines & Ticks
        this.renderAxesAndGrid(ctx, pad, plotW, plotH);

        // Render Series
        for (const s of this.series) {
            if (!s.data || s.data.length === 0) continue;
            ctx.save();
            ctx.strokeStyle = s.color || '#d8a36b';
            ctx.lineWidth = s.lineWidth || 2;
            if (s.dash) ctx.setLineDash(s.dash);

            ctx.beginPath();
            let first = true;
            for (const pt of s.data) {
                const px = this.xToScreen(pt.x);
                const py = this.yToScreen(pt.y);
                if (first) {
                    ctx.moveTo(px, py);
                    first = false;
                } else {
                    ctx.lineTo(px, py);
                }
            }
            ctx.stroke();
            ctx.restore();

            // Points
            if (s.showPoints !== false) {
                ctx.fillStyle = s.color || '#d8a36b';
                for (const pt of s.data) {
                    const px = this.xToScreen(pt.x);
                    const py = this.yToScreen(pt.y);
                    ctx.beginPath();
                    ctx.arc(px, py, s.pointRadius || 3.5, 0, Math.PI * 2);
                    ctx.fill();
                }
            }
        }

        // Legend
        if (this.options.showLegend && this.series.length > 0) {
            this.renderLegend(ctx, pad, plotW);
        }

        // Tooltip
        if (this.hoverPoint) {
            this.renderTooltip(ctx, this.hoverPoint);
        }
    }

    renderAxesAndGrid(ctx, pad, plotW, plotH) {
        ctx.strokeStyle = '#30362e';
        ctx.lineWidth = 1;
        ctx.fillStyle = '#a4a799';
        ctx.font = '10px -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif';

        // Y-axis grid & labels (5 divisions)
        const yTicks = 5;
        for (let i = 0; i <= yTicks; ++i) {
            const frac = i / yTicks;
            const py = pad.top + plotH - frac * plotH;
            ctx.beginPath();
            ctx.moveTo(pad.left, py);
            ctx.lineTo(pad.left + plotW, py);
            ctx.stroke();

            let val;
            if (this.options.logY) {
                const lmin = Math.log10(Math.max(1e-12, this.bounds.minY));
                const lmax = Math.log10(Math.max(1e-12, this.bounds.maxY));
                val = Math.pow(10, lmin + frac * (lmax - lmin));
            } else {
                val = this.bounds.minY + frac * (this.bounds.maxY - this.bounds.minY);
            }

            ctx.textAlign = 'right';
            ctx.fillText(this.formatNumber(val), pad.left - 8, py + 3);
        }

        // X-axis grid & labels (5 divisions)
        const xTicks = 5;
        for (let i = 0; i <= xTicks; ++i) {
            const frac = i / xTicks;
            const px = pad.left + frac * plotW;
            ctx.beginPath();
            ctx.moveTo(px, pad.top);
            ctx.lineTo(px, pad.top + plotH);
            ctx.stroke();

            let val;
            if (this.options.logX) {
                const lmin = Math.log10(Math.max(1e-12, this.bounds.minX));
                const lmax = Math.log10(Math.max(1e-12, this.bounds.maxX));
                val = Math.pow(10, lmin + frac * (lmax - lmin));
            } else {
                val = this.bounds.minX + frac * (this.bounds.maxX - this.bounds.minX);
            }

            ctx.textAlign = 'center';
            ctx.fillText(this.formatNumber(val), px, pad.top + plotH + 16);
        }

        // Axis Titles
        ctx.fillStyle = '#d6d6cb';
        ctx.font = '11px -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif';
        // X Label
        ctx.textAlign = 'center';
        ctx.fillText(this.options.xLabel, pad.left + plotW / 2, pad.top + plotH + 34);

        // Y Label
        ctx.save();
        ctx.translate(16, pad.top + plotH / 2);
        ctx.rotate(-Math.PI / 2);
        ctx.textAlign = 'center';
        ctx.fillText(this.options.yLabel, 0, 0);
        ctx.restore();

        // Plot Border
        ctx.strokeStyle = '#454b40';
        ctx.strokeRect(pad.left, pad.top, plotW, plotH);
    }

    renderLegend(ctx, pad, plotW) {
        let lx = pad.left + plotW - 10;
        const ly = 20;
        ctx.font = '11px -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif';
        ctx.textAlign = 'right';

        for (let i = this.series.length - 1; i >= 0; --i) {
            const s = this.series[i];
            const textWidth = ctx.measureText(s.label).width;
            ctx.fillStyle = '#d6d6cb';
            ctx.fillText(s.label, lx, ly);

            ctx.fillStyle = s.color || '#d8a36b';
            ctx.fillRect(lx - textWidth - 14, ly - 8, 10, 8);
            lx -= (textWidth + 30);
        }
    }

    renderTooltip(ctx, p) {
        ctx.save();
        // Highlight circle
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(p.px, p.py, 6, 0, Math.PI * 2);
        ctx.stroke();

        const text = `${p.label ? p.label + ': ' : ''}x=${this.formatNumber(p.x)}, y=${this.formatNumber(p.y)}`;
        ctx.font = '11px -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif';
        const tw = ctx.measureText(text).width;

        let tx = p.px + 10;
        let ty = p.py - 25;
        if (tx + tw + 16 > this.width) tx = p.px - tw - 20;
        if (ty < 10) ty = p.py + 15;

        ctx.fillStyle = 'rgba(28, 32, 27, 0.96)';
        ctx.strokeStyle = '#5b6154';
        ctx.lineWidth = 1;
        ctx.fillRect(tx, ty, tw + 16, 22);
        ctx.strokeRect(tx, ty, tw + 16, 22);

        ctx.fillStyle = '#eeece3';
        ctx.textAlign = 'left';
        ctx.fillText(text, tx + 8, ty + 15);
        ctx.restore();
    }

    formatNumber(n) {
        if (Math.abs(n) < 1e-4 && n !== 0) return n.toExponential(2);
        if (Math.abs(n) >= 1e4) return n.toExponential(2);
        return parseFloat(n.toPrecision(4)).toString();
    }
}

