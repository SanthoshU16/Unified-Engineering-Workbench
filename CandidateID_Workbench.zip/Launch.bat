@echo off
setlocal
echo ========================================================
echo       Starting Unified Engineering Workbench...
echo ========================================================

set SCRIPT_DIR=%~dp0
cd /d "%SCRIPT_DIR%"

if exist "dist\windows-x64\workbench_server.exe" (
    start "" "dist\windows-x64\workbench_server.exe" --port 8080 --web-root "%SCRIPT_DIR%"
) else if exist "workbench_server.exe" (
    start "" "workbench_server.exe" --port 8080 --web-root "%SCRIPT_DIR%"
) else if exist "build\backend\Release\workbench_server.exe" (
    start "" "build\backend\Release\workbench_server.exe" --port 8080 --web-root "%SCRIPT_DIR%"
) else if exist "build\backend\workbench_server.exe" (
    start "" "build\backend\workbench_server.exe" --port 8080 --web-root "%SCRIPT_DIR%"
) else (
    echo [Development Mode] No packaged Windows runtime was found.
    echo CMake 3.20+ and a C++17 compiler are required for this source build.
    cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
    if errorlevel 1 goto build_error
    cmake --build build --config Release
    if errorlevel 1 goto build_error
    if exist "build\backend\Release\workbench_server.exe" (
        start "" "build\backend\Release\workbench_server.exe" --port 8080 --web-root "%SCRIPT_DIR%"
    ) else if exist "build\backend\workbench_server.exe" (
        start "" "build\backend\workbench_server.exe" --port 8080 --web-root "%SCRIPT_DIR%"
    ) else (
        echo [Error] Could not launch workbench_server.exe.
        pause
        exit /b 1
    )
)

echo Workbench launched successfully. Browser will open automatically.
timeout /t 3 /nobreak >nul
exit /b 0

:build_error
echo [Error] Source build failed. Install CMake 3.20+ and a C++17 compiler, or use the packaged Windows x64 runtime.
pause
exit /b 1

