#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "========================================================"
echo "      Starting Unified Engineering Workbench...        "
echo "========================================================"

if [ -f "./build/backend/workbench_server" ]; then
    ./build/backend/workbench_server --port 8080 --web-root "$SCRIPT_DIR"
elif [ -f "./workbench_server" ]; then
    ./workbench_server --port 8080 --web-root "$SCRIPT_DIR"
else
    echo "[Notice] Pre-built binary not found. Building with CMake..."
    cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
    cmake --build build --config Release
    ./build/backend/workbench_server --port 8080 --web-root "$SCRIPT_DIR"
fi

