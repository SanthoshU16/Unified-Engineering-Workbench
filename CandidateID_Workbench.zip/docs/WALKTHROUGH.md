# Unified Engineering Workbench — Walkthrough & Verification Evidence

**PASS Science Works | R&D Internship Assessment 2026–2027**  
**Document ID:** UEW-WALKTHROUGH-001  
**Updated:** 2026-11-11  
**Verification Environment:** macOS / Apple silicon. Windows packaging was not built or verified in this environment.  

> This file documents the demonstration flow and captured command-line checks. It does not contain a live screen recording or screenshots; the interaction descriptions below are a walkthrough script, not recorded evidence.

---

## 1. Build & Test Suite Verification Log

```bash
$ cmake -S . -B /tmp/uew-final-build -DCMAKE_BUILD_TYPE=Release
-- The CXX compiler identification is AppleClang 21.0.0.21000334
-- Configuring done
-- Generating done
-- Build files have been written to: /tmp/uew-final-build

$ cmake --build /tmp/uew-final-build --config Release -j4
[100%] Built target workbench_server
[100%] Built target workbench_tests

$ ctest --test-dir /tmp/uew-final-build --output-on-failure
1/1 Test #1: AllWorkbenchTests ... Passed (0.46 sec)
100% tests passed, 0 tests failed

$ /tmp/uew-final-build/backend/workbench_tests
Test Summary: 11/11 tests passed

$ node --check frontend/src/app.js
$ node --check frontend/src/view_geometry.js
$ node --check frontend/src/view_thermal.js
$ node --check frontend/src/renderer3d.js
$ node --check frontend/src/chart_engine.js
# All five JavaScript syntax checks exited successfully.
```

---

## 2. Interactive User Interface Walkthrough

### View 1: Geometry View (Task B ASCII STL 3D Viewer)
- **Action**: User navigates to the *Geometry (STL)* tab.
- **Log / Event**:
  `[HttpServer] POST /api/cad/stl/parse filepath="samples/geometry/sample_heatsink.stl"`
- **Observed Behavior**:
  - The C++ backend parses the sample STL and reports its triangle count and dimensions.
  - Metadata card displays: Solid: `heatsink_assessment`, Triangles: `72`, Dimensions: `100.0 x 100.0 x 50.0 mm`, Size: `14.4 KB`.
  - WebGL viewport renders the heat sink with brushed copper shading and directional lighting.
  - User drags with left-mouse to orbit, right-mouse to pan, and wheel to zoom. Clicking *Toggle Wireframe* reveals the triangular mesh topology.
  - Negative validation tested: Selecting `malformed_corrupt.stl` immediately triggers the red actionable alert banner:  
    `STL Validation Rejection: Parse Error [line 4]: Non-finite vertex coordinate (NaN or Inf detected).`

---

### View 2: Thermal Analysis View (Task B ANSYS & Task C FEA)
- **Mode A: 1D Thermal FEA Solver (Task C)**:
  - Input parameters: $L = 1.0\text{ m}, A = 10^{-4}\text{ m}^2, k = 10\text{ W/(m K)}, q = 10000\text{ W/m}^3, T(0) = 100^\circ\text{C}, T(L) = 20^\circ\text{C}, N = 10$.
  - User clicks *Solve FEA (C++)*.
  - Status updates: `FEA Solved: N=10, Max Midpoint Error=1.250000 °C, Max Nodal Error=2.84e-14 °C`.
  - Chart 1 renders $T(x)$ parabola reaching peak $185.0^\circ\text{C}$ at midpoint, overlaying discrete FEA nodes on the exact analytical curve.
  - Chart 2 renders log-log mesh convergence across $N = 10, 20, 40, 80$, showing an exact second-order slope $\alpha = 2.000$.
  - Table populates with midpoint errors: $1.25^\circ\text{C} \to 0.3125^\circ\text{C} \to 0.078125^\circ\text{C} \to 0.0195312^\circ\text{C}$.
  - User clicks *Export FEA CSV*, which instantly downloads `fea_thermal_N10_results.csv`.
- **Mode B: ANSYS 3D Point Cloud (Task B)**:
  - User switches dropdown to *ANSYS 3D Nodal Temperature Export*.
  - The C++ backend parses `samples/thermal/ansys_nodal_temperature.csv` (1,440 nodes).
  - WebGL viewport renders a 3D point cloud colored by temperature from $25.0^\circ\text{C}$ (dark green) to $118.8^\circ\text{C}$ (terracotta).
  - Hovering the mouse over a node displays the inspection tooltip:  
    `Node ID: 524 | X: 0.0000 m | Y: 0.0000 m | Z: 0.0100 m | Temp: 98.42 °C`.

---

### View 3: Performance View (Task D Multicore Scaling)
- **Action**: User enters workload parameters: 20,000 thermal cases, mesh size $N = 200$, RNG Seed = 42, and clicks *Run Parallel Benchmark (C++)*.
- **Observed Behavior**:
  - UI remains completely responsive with a pulsing progress badge (`Multicore C++ Pool Running`).
  - Warm-up pass executed, followed by 5 repetitions on 1, 2, and 4 threads.
  - Results Table populates:
    - 1 Worker (Serial): **52.292 ms** (Baseline 1.00x)
    - 2 Workers: **32.148 ms** (Speedup **1.63x**, Efficiency 81.3%)
    - 4 Workers: **20.699 ms** (Speedup **2.53x**, Efficiency 63.2%)
  - Agreement Badge displays: `Agreement: PASS (Max Diff = 0.00e+00 °C <= 1e-8)`.
  - Dual bar/line chart renders execution time reduction and speedup scaling curve.

---

### View 4: Hardware View (Task E Embedded Workbench)
- **Action**: User opens the *Hardware* view.
- **Observed Behavior**:
  - Top diagram renders the complete SVG host-connected block diagram showing the Host USB hub, MCU, FPGA, and JTAG Debug Adapter with power rails and signal lines.
  - Pin-voltage specification table details logic levels, level shifters, and signal mastership.
  - User clicks *Connect* on STM32 MCU: status badge transitions from grey `DISCONNECTED` to green `CONNECTED` $\to$ blue `STREAMING`. Telemetry box streams real-time voltage ($3.298\text{ V}$) and temperature ($42.5^\circ\text{C}$).
  - User clicks *Inject Timeout*: badge flashes red `ERROR_TIMEOUT`, and alert banner warns:  
    `[ALERT] Communication timeout detected! Deadline 250ms exceeded without ACK.`
  - User clicks *Auto-Recover*: recovery routine clears buffers, resynchronizes clocks, and seamlessly resumes telemetry.

---

### View 5: Backpropagation Lab (Task F)
- **Action**: User opens the *Backprop Lab* tab.
- **Observed Behavior**:
  - Verification Table displays Step 0 analytical derivatives and central finite differences ($\epsilon = 10^{-6}$):
    - $w$: Analytical: `-1.20946448`, FD: `-1.20946448` (Diff: $1.13 \times 10^{-10}$) $\to$ **PASSED**
    - $b$: Analytical: `-1.20946448`, FD: `-1.20946448` (Diff: $1.13 \times 10^{-10}$) $\to$ **PASSED**
    - $v$: Analytical: `-0.71068205`, FD: `-0.71068205` (Diff: $5.25 \times 10^{-11}$) $\to$ **PASSED**
    - $c$: Analytical: `-1.53788284`, FD: `-1.53788284` (Diff: $1.12 \times 10^{-10}$) $\to$ **PASSED**
  - Updated parameters ($\eta = 0.1$): $w_1 = 0.62094645, b_1 = 0.12094645, v_1 = 1.07106820, c_1 = 0.15378828$.
  - 100-step training loss curve displays smooth monotonic descent from $1.1825$ down to $1.70 \times 10^{-20}$.

