#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$SCRIPT_DIR"

if [ ! -f "build/backend/workbench_server" ]; then
    echo "Building workbench first..."
    ./scripts/build.sh
fi

echo "Running all headless computational tasks and exporting evidence to results/..."
mkdir -p results
./build/backend/workbench_server --run-all-headless

echo "Results successfully generated in results/:"
ls -lh results/

