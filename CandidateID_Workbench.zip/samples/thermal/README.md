# Thermal FEA / ANSYS Datasets & Provenance (Task B & C)

This directory contains nodal temperature datasets and export specifications for the Unified Engineering Workbench.

## Files

1. `ansys_nodal_temperature.csv`:
   - **Description**: 3D nodal temperature point cloud representing steady-state thermal conduction in an electronics cooling heat sink assembly.
   - **Provenance**: **SYNTHETIC DATASET** generated procedurally for this assessment. This file is explicitly labelled synthetic and is not represented as an authentic commercial ANSYS export.
   - **Schema**:
     - `node_id`: Integer, unique global node identifier.
     - `x_m`: Double, node X coordinate in meters ($m$).
     - `y_m`: Double, node Y coordinate in meters ($m$).
     - `z_m`: Double, node Z coordinate in meters ($m$).
     - `temperature_C`: Double, nodal temperature in degrees Celsius ($^\circ\text{C}$).
   - **Spatial Extent**: $X \in [-0.05, 0.05]\text{ m}$, $Y \in [-0.05, 0.05]\text{ m}$, $Z \in [0.0, 0.05]\text{ m}$.
   - **Temperature Extent**: Min: $25.00\ ^\circ\text{C}$, Max: $118.82\ ^\circ\text{C}$, Mean: $41.87\ ^\circ\text{C}$.
   - **Node Count**: 1,440 discrete finite-element mesh nodes.

2. `malformed_empty.csv`:
   - **Description**: Zero-byte CSV file to verify empty-file detection and explanatory error handling.

3. `malformed_corrupt.csv`:
   - **Description**: Corrupted CSV containing `NaN` floating point entries, incomplete rows, and missing column values.

## Supported Input Limits

- **Maximum File Size**: 50 MB (enforced for file and browser uploads)
- **Interactive Node Limit**: 200,000 nodes; larger point clouds are rejected with an actionable message.
- **Validation Rules**:
  - File must contain a header with `node_id`, `x_m`, `y_m`, `z_m`, `temperature_C`.
  - Coordinates and temperatures must be strictly finite real numbers (no `NaN`, `Inf`).
  - Node IDs must be unique positive integers.

