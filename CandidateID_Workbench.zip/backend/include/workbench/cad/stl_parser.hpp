#pragma once

#include "workbench/common/types.hpp"
#include <string>

namespace workbench {
namespace cad {

class STLParser {
public:
    // Parse an ASCII STL file from disk
    static STLModel parse_file(const std::string& filepath);

    // Parse ASCII STL content from a string buffer
    static STLModel parse_string(const std::string& content, const std::string& source_name = "buffer");

    // Documented maximum tested file size limit (50 MB)
    static constexpr size_t MAX_TESTED_FILE_SIZE_BYTES = 50 * 1024 * 1024;
    // Keep parsing, JSON transfer, and interactive rendering within one explicit limit.
    static constexpr size_t MAX_RECOMMENDED_TRIANGLES = 200000;
};

} // namespace cad
} // namespace workbench

