#pragma once

#include <string>

namespace workbench {
namespace system_info {

int logical_cpu_count();
int physical_cpu_count();
std::string cpu_model();

} // namespace system_info
} // namespace workbench
